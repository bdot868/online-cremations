import React from 'react'
import {  } from 'semantic-ui-react'

const ConfirmationModal = (props) => {
  return (

  <div>Successfully submitted your request</div>
  )
}

export default ConfirmationModal;
