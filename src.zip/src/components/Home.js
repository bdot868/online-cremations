import React from 'react';
import { List, Button } from 'semantic-ui-react'
import ProductModal from './ProductModal';

class Home extends React.Component {
  constructor(props){
    super(props);

    this.state = {
      alternativeContainer: {
        title: 'Alternative Container (2-000)',
        description: 'Cardboard Box',
        imageSrc: 'https://dazl12ygp0r17.cloudfront.net/douglassandzook/products/Alternative-Container.jpg?1542415893',
        price: '$58.00',
        disclaimer: 'The Law requires the use of a cremation container to encase the body during the cremation process. Our cremation container is a basic cardboard box.'
      },
      urn: {
        title: 'Basic Plastic Urn',
        description: 'Plastic Urn',
        imageSrc: 'https://dazl12ygp0r17.cloudfront.net/douglassandzook/products/Plastic-Urn.jpg?1551682610',
        price: '$34.00'
      }
    }
  }

  saveAndContinue = (e) =>{
    e.preventDefault()
    this.props.nextStep()
  }

  render (){
    return (
          <div className="cremation-package">
            <div className="cremation-package-title">
              <div className="package-title">Essential Cremation Package</div>
              <div className="package-price">$1,995</div>
            </div>
            <div className="package-features">
              <p>This package features:</p>
              <List bulleted>
                <List.Item>Basic use of facilities & services</List.Item>
                <List.Item>Transfer of deceased into our care</List.Item>
                <List.Item>Refrigeration</List.Item>
                <List.Item>Crematory Fee</List.Item>
                <ProductModal product={this.state.alternativeContainer}/>
                <ProductModal product={this.state.urn}/>
                <List.Item>Death Certificate Processing</List.Item>
                <List.Item>Death Certificate (1)</List.Item>
                <List.Item>Permit (1)</List.Item>
              </List>
            </div>
            <div>
              <Button className="ui right floated" onClick={this.saveAndContinue}>Continue</Button>
            </div>
          </div>
    );
  }
}

export default Home;
