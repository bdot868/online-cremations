import React from 'react'

const FuneralHome = () => {
  return (
    <div>
      <h3>Funeral Home</h3>
      <p>Douglass & Zook Funeral and Cremation Services</p>
      <h3>Funeral Director</h3>
      <p>Matt Zook</p>
    </div>
  )
}

export default FuneralHome;
